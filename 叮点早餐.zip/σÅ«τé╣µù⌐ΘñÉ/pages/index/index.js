var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrls: [
      'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1534751870922&di=e5439c9183744008ef04df383efca09a&imgtype=0&src=http%3A%2F%2Fpic35.photophoto.cn%2F20150616%2F0013026450510845_b.jpg',
      'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1534751914900&di=fbbf37024f0ce42bf439a4a8b811baee&imgtype=0&src=http%3A%2F%2Fimg.kj-cy.cn%2Fuploads%2Flitimg%2F20161213%2F1481618427555583.jpg'
    ],
    tom: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setStorageSync('schoolId', "sunwou20180525094800369")
    app.globalData.school.sunwouId = "sunwou20180525094800369"
  },
  getDay() {
    var date = new Date();
    var str = (date.getMonth() + 1) + '.' + (date.getDate() + 1)
    var weekday = ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"];
    var dy = '';
    var num = 0;
    switch (date.getDay()) {
      case 0: num += 1; break;
      case 1: num += 7; break;
      case 2: num += 6; break;
      case 3: num += 5; break;
      case 4: num += 4; break;
      case 5: num += 3; break;
      case 6: num += 2; break;
    }
    dy = (date.getMonth() + 1) + '.'
    this.setData({
      tom: str,
      dy: dy
    })
  },
  navtotime() {
    if (wx.getStorageSync("time")) {
      wx.navigateTo({
        url: '/pages/menu/menu?id=e7cb0-20180711102529855',
      })
    } else {
      wx.navigateTo({
        url: '/pages/set/set',
      })
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (wx.getStorageSync("time")) {
      this.getDay()
      this.setData({
        time: wx.getStorageSync("time"),
        hol: wx.getStorageSync("hol")
      })
    }
  },

 

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})